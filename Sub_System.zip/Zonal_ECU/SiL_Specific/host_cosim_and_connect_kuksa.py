import numpy as np
import matplotlib.pyplot as plt
from fmpy import simulate_fmu, read_model_description, extract
from enum import IntEnum
from fmpy.fmi2 import FMU2Slave
import threading
import time
import cosim_environment

from kuksa_client.grpc import VSSClient
from kuksa_client.grpc import Datapoint

# --- Central Signal Configuration ---
# All VSS signals are defined here for easy management.
VSS_SIGNALS = {
    # This is the original signal used for the "is light on" logic
    'light_is_on': 'Vehicle.Cabin.Light.Spotlight.Row1.PassengerSide.IsLightOn',
    
    # This is the original signal used for the "airbag deployed" logic
    'airbag_is_deployed': 'Vehicle.Cabin.Seat.Row1.PassengerSide.Airbag.IsDeployed',
    
    # add other signals to monitor here:
    #'vehicle_speed': 'Vehicle.Speed', # float
    'cruise_control_active': 'Vehicle.ADAS.CruiseControl.IsActive',
    'crash_is_simulated': 'Vehicle.CrashOutput.InjectionCrashType',
    'crash_signal_trigger': 'Vehicle.CrashOutput.DetectionCrashType',
}


class code_stage_en(IntEnum):
    development = 0
    testing = 1
    release = 2

CODE_STAGE = code_stage_en.testing

def print_terminal(arg, code_stage: list[code_stage_en] = [code_stage_en.development,code_stage_en.testing]) -> None: 
    if CODE_STAGE in code_stage or code_stage:
        print(arg)

class CoSim_Host:
    def __init__(self):
        self.step_size = 0.01
        self.time = time.time()

    def connect_to_broker_thread(self):
        kuksaDataBroker_IP = '127.0.0.1'
        kuksaDataBroker_Port = 55555
        
        # Get the list of VSS paths to request from our config
        signal_paths_to_get = list(VSS_SIGNALS.values())

        while True:
            try:
                with VSSClient(kuksaDataBroker_IP, kuksaDataBroker_Port) as client:
                    # Request all configured signals at once
                    signals_from_kuksha = client.get_current_values(signal_paths_to_get)

                    # --- Handle incoming signals using friendly names ---
                    
                    # Check for the light signal
                    airbag_simulation_signal = signals_from_kuksha.get(VSS_SIGNALS['crash_is_simulated'])
                    if airbag_simulation_signal is not None:
                        if cosim_environment.from_kuksha_CrashSignalSimulate_u8 != airbag_simulation_signal.value:
                            print_terminal(f"from_kuksha_CrashSignalSimulate_u8: {cosim_environment.from_kuksha_CrashSignalSimulate_u8} -> {airbag_simulation_signal.value}")
                            cosim_environment.from_kuksha_CrashSignalSimulate_u8 = airbag_simulation_signal.value
                            latency_start_time = time.time()
                    
                    # --- Handle outgoing signals using friendly names ---

                    # Check for the airbag signal
                    airbag_deployed_path = VSS_SIGNALS['crash_signal_trigger']
                    airbag_crash_signal = signals_from_kuksha.get(airbag_deployed_path)
                    if airbag_crash_signal is not None:
                        if cosim_environment.to_kuksha_CrashSignalTrigger != airbag_crash_signal.value:
                            print_terminal(f"to_kuksha_CrashSignalTrigger: {airbag_crash_signal.value} -> {cosim_environment.to_kuksha_CrashSignalTrigger}")
                            client.set_current_values({airbag_deployed_path: Datapoint(cosim_environment.to_kuksha_CrashSignalTrigger)})
                            if latency_start_time is not None:
                                end_time = time.time()
                                time_delta = end_time - latency_start_time
                                print_terminal(f"--> Delay time: {time_delta:.4f} s.")
                                # reset latency start time
                                latency_start_time = None

            except Exception as e:
                # This will print the actual error if something goes wrong
                print_terminal(f"An error occurred: {e}")
                time.sleep(2) # Wait a bit longer on error

            time.sleep(self.step_size)

    def run_cosim_thread(self):
        cosim_environment.run_cosim()

    def start_cosim_host(self):
        try:
            # Declare threads
            cosim_thread = threading.Thread(target=self.run_cosim_thread, args=())
            kuksa_connection_thread = threading.Thread(target=self.connect_to_broker_thread, args=())

            # Start threads
            cosim_thread.start()
            kuksa_connection_thread.start()

            # Wait threads to finish
            cosim_thread.join()
            kuksa_connection_thread.join()

        except Exception as e:
            print_terminal(f"[ERROR] {e}")


if __name__ == '__main__':
    cosim_host = CoSim_Host()
    cosim_host.start_cosim_host()