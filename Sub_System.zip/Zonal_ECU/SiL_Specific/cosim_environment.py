# ==============================================================================
#
#  Co-simulation Script with CSV Input
#
#  This script co-simulates vECU_zonal and vECU_airbag, with the initial
#  input coming from an 'input_data.csv' file.
#
# ==============================================================================

import time
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from fmpy import read_model_description, extract
from fmpy.fmi2 import FMU2Slave

# --- Configuration ---
VECU_ZONAL_FMU_PATH = os.path.join( 'vECU_zonal.fmu')
VECU_AIRBAG_FMU_PATH = os.path.join( '..','..','Airbag_ECU','SiL_Specific', 'vECU_Airbag.fmu')
VSENSOR_FMU_PATH = os.path.join(  '..','..','Airbag_ECU','SiL_Specific', 'vSensor.fmu')
#INPUT_FILE = 'input_data.csv'  # Changed back to .csv
START_TIME = 0.0
STOP_TIME = None
STEP_SIZE = 0.0001

# init value of kuksha buffers
from_kuksha_CrashSignalSimulate_u8 = 0
to_kuksha_CrashSignalTrigger = 0


def run_cosim():

    # Load Input Data from CSV 
    # print(f"Reading input data from {INPUT_FILE}...")
    # try:
    #     # Changed back to read_csv
    #     input_df = pd.read_csv(INPUT_FILE)
    # except FileNotFoundError:
    #     print(f"ERROR: Input file not found at '{INPUT_FILE}'")
    #     print("Please create the CSV file as described in the guide.")
    #     return

    # Load and Initialize FMUs 
    #print("Loading and initializing FMUs...")
    zonal_desc = read_model_description(VECU_ZONAL_FMU_PATH)
    airbag_desc = read_model_description(VECU_AIRBAG_FMU_PATH)
    sensor_desc = read_model_description(VSENSOR_FMU_PATH)

    unzip_zonal = extract(VECU_ZONAL_FMU_PATH)
    unzip_airbag = extract(VECU_AIRBAG_FMU_PATH)
    unzip_vsensor = extract(VSENSOR_FMU_PATH)

    zonal_ecu = FMU2Slave(guid=zonal_desc.guid, modelIdentifier=zonal_desc.coSimulation.modelIdentifier, unzipDirectory=unzip_zonal)
    airbag_ecu = FMU2Slave(guid=airbag_desc.guid, modelIdentifier=airbag_desc.coSimulation.modelIdentifier, unzipDirectory=unzip_airbag)
    sensor_ecu = FMU2Slave(guid=sensor_desc.guid,modelIdentifier=sensor_desc.coSimulation.modelIdentifier, unzipDirectory=unzip_vsensor)

    for fmu in [zonal_ecu, sensor_ecu, airbag_ecu]:
        fmu.instantiate()
        fmu.setupExperiment(startTime=START_TIME, stopTime=STOP_TIME)
        fmu.enterInitializationMode()
        fmu.exitInitializationMode()

    # Get Variable Handles (Value References) 
    zonal_vr = {v.name: v.valueReference for v in zonal_desc.modelVariables}
    airbag_vr = {v.name: v.valueReference for v in airbag_desc.modelVariables}
    sensor_vr = {v.name: v.valueReference for v in sensor_desc.modelVariables}

    global from_kuksha_CrashSignalSimulate_u8
    global to_kuksha_CrashSignalTrigger
    # --- 4. Simulation Loop ---
    current_time = START_TIME
    #results = [] # To store data for plotting

    print("\n--- Starting Co-Simulation Loop ---\n")

    # Create an iterator for the input data
    #input_iterator = input_df.iterrows()
    #_, current_input_row = next(input_iterator, (None, None))
    # Initialize kuksha_sends_data with the first value
    #kuksha_sends_data = 0
    #data_from_airbag = 0 # This holds the return value from the previous step
    #if current_input_row is not None:
    #    kuksha_sends_data = int(current_input_row['In_From_Kuksha_u8'])

    while True:
        # Get the input value for the current time from the CSV data
        #if current_input_row is not None and current_time >= current_input_row['time']:
        #    kuksha_sends_data = int(current_input_row['In_From_Kuksha_u8'])
        #    _, current_input_row = next(input_iterator, (None, None))
        
        #print(f"--- Time: {current_time:.2f}s ---")

        # Set input from Kuksha (CSV) to Zonal
        #print(f"[Kuksha -> Zonal] Sending data: {from_kuksha_CrashSignalSimulate_u8}")
        zonal_ecu.setInteger([zonal_vr['In_From_Kuksha_u8']], [from_kuksha_CrashSignalSimulate_u8])    
        
        # ** Step Zonal: Zonal Gateway processes both inputs **
        zonal_ecu.doStep(currentCommunicationPoint=current_time, communicationStepSize=STEP_SIZE)
        
        # Get the final output that would go back to Kuksha
        
        # Get the data that Zonal passes to the Airbag ECU
        data_for_vsensor = zonal_ecu.getInteger([zonal_vr['Out_To_Airbag_u8']])[0]
        #print(f"[Zonal -> Airbag]  Passing data: {data_for_airbag}")
        #airbag_ecu.setInteger([airbag_vr['VR_IN_INJECTED_CRASH_TYPE_U8']], [data_for_airbag])
        #data_for_vsensor = airbag_ecu.getInteger([airbag_vr['VR_OUT_DETECTED_CRASH_TYPE_U8']])[0]
        #print(f"[Airbag -> Zonal]  Returning data for next step: {data_from_airbag}\n")
        # Set last data from airbag to zonal
        # At t=0, this will be 0. For subsequent steps, it's the value from the previous step.
        sensor_ecu.setInteger([sensor_vr['CrashInfo']], [data_for_vsensor])
        
        sensor_ecu.doStep(currentCommunicationPoint=current_time, communicationStepSize=STEP_SIZE)
        sensorData1 = sensor_ecu.getReal([sensor_vr['Sensor1_Output']])[0]
        sensorData2 = sensor_ecu.getReal([sensor_vr['Sensor2_Output']])[0]
        sensorData3 = sensor_ecu.getReal([sensor_vr['Sensor3_Output']])[0]
        sensorData4 = sensor_ecu.getReal([sensor_vr['Sensor4_Output']])[0]
        sensorData5 = sensor_ecu.getReal([sensor_vr['Sensor5_Output']])[0]
        sensorData6 = sensor_ecu.getReal([sensor_vr['Sensor6_Output']])[0]

        airbag_ecu.setReal([airbag_vr['VR_IN_SENSOR_1_F32']], [sensorData1])
        airbag_ecu.setReal([airbag_vr['VR_IN_SENSOR_2_F32']], [sensorData2])
        airbag_ecu.setReal([airbag_vr['VR_IN_SENSOR_3_F32']], [sensorData3])
        airbag_ecu.setReal([airbag_vr['VR_IN_SENSOR_4_F32']], [sensorData4])
        airbag_ecu.setReal([airbag_vr['VR_IN_SENSOR_5_F32']], [sensorData5])
        airbag_ecu.setReal([airbag_vr['VR_IN_SENSOR_6_F32']], [sensorData6])
        

        # ** Step Airbag: Airbag ECU runs its logic (value + 1) **
        airbag_ecu.doStep(currentCommunicationPoint=current_time, communicationStepSize=STEP_SIZE)
        
        # Get the return value from the airbag, which will be used in the *next* loop iteration
        data_from_airbag = airbag_ecu.getInteger([airbag_vr['VR_OUT_DETECTED_CRASH_TYPE_U8']])[0]
        #print(f"[Airbag -> Zonal]  Returning data for next step: {data_from_airbag}\n")
        # Set last data from airbag to zonal
        # At t=0, this will be 0. For subsequent steps, it's the value from the previous step.
        zonal_ecu.setInteger([zonal_vr['In_From_Airbag_u8']], [data_from_airbag])
        
       
        to_kuksha_CrashSignalTrigger = zonal_ecu.getInteger([zonal_vr['Out_To_Kuksha_u8']])[0]
        #print(f"[Zonal -> Kuksha]  Final data for client: {to_kuksha_CrashSignalTrigger}")
        # Store results for plotting
        #results.append((current_time, kuksha_sends_data, data_for_airbag, data_from_airbag, final_data_for_kuksha))

        current_time += STEP_SIZE
        time.sleep(STEP_SIZE)

    # --- Terminate FMUs ---
    # print("--- Simulation Finished ---")
    # for fmu in [zonal_ecu, airbag_ecu]:
    #     fmu.terminate()
    #     fmu.freeInstance()
        
    # --- Plot Results ---
    # time_vals, in_kuksha, out_zonal, in_zonal, out_kuksha = zip(*results)
    # plt.figure(figsize=(12, 8))
    # plt.plot(time_vals, in_kuksha, 'o-', label='In_From_Kuksha_u8 (from CSV)')
    # #plt.plot(time_vals, out_zonal, 'x--', label='Out_To_Airbag_u8 (Zonal Out)')
    # #plt.plot(time_vals, in_zonal, 's-', label='In_From_Airbag_u8 (Airbag Out)')
    # plt.plot(time_vals, out_kuksha, 'd--', label='Out_To_Kuksha_u8 (Final Zonal Out)')
    # plt.grid(True)
    # plt.legend()
    # plt.title('Co-Simulation with CSV Input')
    # plt.xlabel('Time (s)')
    # plt.ylabel('Value')
    # plt.show()


if __name__ == '__main__':
    # Check if FMUs exist before running
    if not os.path.exists(VECU_ZONAL_FMU_PATH) or not os.path.exists(VECU_AIRBAG_FMU_PATH):
        print("ERROR: FMU files not found!")
    else:
        run_cosim()
